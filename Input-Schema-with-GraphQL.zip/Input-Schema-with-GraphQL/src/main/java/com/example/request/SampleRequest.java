package com.example.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SampleRequest {

	private String firstName;
	
	private String lastName;
}
